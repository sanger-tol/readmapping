{
  "version": "1.2",
  "dbname": "HiFi_adapter_DB",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "HiFi_adapter_DB.fasta",
  "number-of-letters": 5546,
  "number-of-sequences": 175,
  "last-updated": "2025-07-10T14:20:00",
  "number-of-volumes": 1,
  "bytes-total": 56171,
  "bytes-to-cache": 3749,
  "files": [
    "HiFi_adapter_DB.ndb",
    "HiFi_adapter_DB.nhr",
    "HiFi_adapter_DB.nin",
    "HiFi_adapter_DB.not",
    "HiFi_adapter_DB.nsq",
    "HiFi_adapter_DB.ntf",
    "HiFi_adapter_DB.nto"
  ]
}
